package MyGame;

/**
 * This class extends PuwerUp class. Because of the customer intend to add additional powerups in the future; with PowerUpDecorator
 * customer can extend from this class he/she's new powerup as other implemented powerups.
 * Its empty because its just for relation for now
 */
public abstract class PowerUpDecorator extends PowerUp {

}
